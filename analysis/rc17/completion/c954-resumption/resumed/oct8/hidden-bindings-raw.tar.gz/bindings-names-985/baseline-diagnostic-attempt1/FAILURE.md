# Preserved failed diagnostic attempt1

The process completed72matrix cases but failed its first freshness control. The fixture set expiresAt to the exact boundary while sample() retained a future refreshAt. Production snapshotFresh intentionally uses refreshAt first; therefore the sample correctly remained ready. This is a diagnostic fixture error, not a production expiry defect.

The original diagnostic.mjs, raw result/log, full source manifests and failed receipt are preserved here. The result has no complete/sourceVerified acceptance flag and cannot close this lane. The next attempt explicitly sets both refreshAt and expiresAt to now in the two expiry controls; ordinary matrix data and production source remain unchanged.
